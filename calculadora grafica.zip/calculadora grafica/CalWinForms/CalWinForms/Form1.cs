namespace CalWinForms
{
    public partial class Form1 : Form
    {
        double numero1 = 0;
        double numero2 = 0;
        string operador = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void numeroClick(object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            textBox1.Text += boton.Text;
        }

        private void operadorClick(object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            if (textBox1.Text != "")
            {
                numero1 = Convert.ToDouble(textBox1.Text);
                operador = boton.Text;
                textBox1.Clear();
            }
        }

        private void igualClick(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                numero2 = Convert.ToDouble(textBox1.Text);

                switch (operador)
                {
                    case "+":
                        textBox1.Text = (numero1 + numero2).ToString();
                        break;
                    case "-":
                        textBox1.Text = (numero1 - numero2).ToString();
                        break;
                    case "*":
                        textBox1.Text = (numero1 * numero2).ToString();
                        break;
                    case "/":
                        if (numero2 != 0)
                            textBox1.Text = (numero1 / numero2).ToString();
                        else
                            textBox1.Text = "Error";
                        break;
                }
            }
        }

        private void limpiarClick(object sender, EventArgs e)
        {
            textBox1.Clear();
            numero1 = 0;
            numero2 = 0;
            operador = "";
        }
    }
}
