using System.Globalization;

namespace CalWinForms
{
    public partial class Form1 : Form
    {
        double numero1 = 0;
        double numero2 = 0;
        string operador = "";

        // datos de la calculadora de IVA
        decimal precio = 0;
        decimal cantidad = 0;
        decimal iva = 0;
        decimal descuento = 0;
        bool socio = false;
        bool precioIntroducido = false;
        bool cantidadIntroducida = false;
        CultureInfo es = new CultureInfo("es-ES");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ActualizarSeleccion();
            MostrarResumen();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void numeroClick(object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            textBox1.Text += boton.Text;
        }

        private void operadorClick(object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            if (textBox1.Text != "")
            {
                numero1 = Convert.ToDouble(textBox1.Text);
                operador = boton.Text;
                textBox1.Clear();
            }
        }

        private void igualClick(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                numero2 = Convert.ToDouble(textBox1.Text);

                switch (operador)
                {
                    case "+":
                        textBox1.Text = (numero1 + numero2).ToString();
                        break;
                    case "-":
                        textBox1.Text = (numero1 - numero2).ToString();
                        break;
                    case "*":
                        textBox1.Text = (numero1 * numero2).ToString();
                        break;
                    case "/":
                        if (numero2 != 0)
                            textBox1.Text = (numero1 / numero2).ToString();
                        else
                            textBox1.Text = "Error";
                        break;
                }
            }
        }

        private void limpiarClick(object sender, EventArgs e)
        {
            textBox1.Clear();
            numero1 = 0;
            numero2 = 0;
            operador = "";

            // también se borran los datos del IVA
            precio = 0;
            cantidad = 0;
            iva = 0;
            descuento = 0;
            socio = false;
            precioIntroducido = false;
            cantidadIntroducida = false;
            ActualizarSeleccion();
            MostrarResumen();
        }

        // ---------- Calculadora de IVA y descuentos ----------

        private bool ParseDecimal(string texto, string campo, decimal minimo, out decimal valor)
        {
            valor = 0;
            if (texto.Trim() == "")
            {
                MessageBox.Show("Escribe primero el " + campo + " en el display.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (!decimal.TryParse(texto, NumberStyles.Number, es, out valor))
            {
                MessageBox.Show("El " + campo + " no es un número válido.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (valor < minimo)
            {
                MessageBox.Show("El " + campo + " no puede ser menor que " + minimo + ".", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void precioClick(object sender, EventArgs e)
        {
            decimal valor;
            if (!ParseDecimal(textBox1.Text, "precio", 0, out valor)) return;
            precio = valor;
            precioIntroducido = true;
            textBox1.Clear();
            MostrarResumen();
        }

        private void cantidadClick(object sender, EventArgs e)
        {
            decimal valor;
            if (!ParseDecimal(textBox1.Text, "cantidad", 1, out valor)) return;
            cantidad = valor;
            cantidadIntroducida = true;
            textBox1.Clear();
            MostrarResumen();
        }

        // Botones IVA
        private void ivaClick(object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            switch (boton.Name)
            {
                case "btnIva0": iva = 0; break;
                case "btnIva4": iva = 4; break;
                case "btnIva10": iva = 10; break;
                case "btnIva21": iva = 21; break;
            }
            ActualizarSeleccion();
            MostrarResumen();
        }

        // Botones Descuento
        private void descuentoClick(object sender, EventArgs e)
        {
            Button boton = (Button)sender;
            switch (boton.Name)
            {
                case "btnDto0": descuento = 0; break;
                case "btnDto5": descuento = 5; break;
                case "btnDto10": descuento = 10; break;
                case "btnDto20": descuento = 20; break;
            }
            socio = false;   
            ActualizarSeleccion();
            MostrarResumen();
        }

        // Socio: 30 % fijo. 
        private void socioClick(object sender, EventArgs e)
        {
            socio = !socio;
            ActualizarSeleccion();
            MostrarResumen();
        }

        private void calcularClick(object sender, EventArgs e)
        {
            if (!precioIntroducido || !cantidadIntroducida)
            {
                MessageBox.Show("Primero introduce el precio y la cantidad (botones Precio y Cantidad).",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal dto = descuento;
            if (socio) dto = 30;

            decimal subtotal = precio * cantidad;
            decimal sinIva = subtotal * (1 - dto / 100);
            decimal conIva = sinIva * (1 + iva / 100);

            textBox1.Text = conIva.ToString("F2", es);
            MostrarResumen();
            lblResumen.Text += "\nSin IVA: " + sinIva.ToString("C2", es) +
                               "\nCon IVA: " + conIva.ToString("C2", es);
        }

        // Pintar de otro color los botones elegidos
        private void ActualizarSeleccion()
        {
            Pintar(btnIva0, iva == 0);
            Pintar(btnIva4, iva == 4);
            Pintar(btnIva10, iva == 10);
            Pintar(btnIva21, iva == 21);
            Pintar(btnDto0, !socio && descuento == 0);
            Pintar(btnDto5, !socio && descuento == 5);
            Pintar(btnDto10, !socio && descuento == 10);
            Pintar(btnDto20, !socio && descuento == 20);
            Pintar(btnSocio, socio);
        }

        private void Pintar(Button boton, bool elegido)
        {
            if (elegido)
                boton.BackColor = Color.Gold;
            else
                boton.BackColor = SystemColors.Highlight;
        }

        private void MostrarResumen()
        {
            string p = "-";
            string c = "-";
            if (precioIntroducido) p = precio.ToString("C2", es);
            if (cantidadIntroducida) c = cantidad.ToString();

            string dto = descuento + " %";
            if (socio) dto = "30 % (socio)";

            lblResumen.Text = "Precio: " + p + "   Cantidad: " + c +
                              "\nIVA: " + iva + " %   Descuento: " + dto;
        }
    }
}
