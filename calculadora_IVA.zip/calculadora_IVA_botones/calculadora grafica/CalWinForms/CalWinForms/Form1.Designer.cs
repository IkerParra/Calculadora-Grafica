﻿namespace CalWinForms
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            flowLayoutPanel1 = new FlowLayoutPanel();
            textBox1 = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            button20 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button8 = new Button();
            button12 = new Button();
            button10 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button9 = new Button();
            button11 = new Button();
            button4 = new Button();
            button16 = new Button();
            btnIva0 = new Button();
            btnIva4 = new Button();
            btnIva10 = new Button();
            btnIva21 = new Button();
            btnDto0 = new Button();
            btnDto5 = new Button();
            btnDto10 = new Button();
            btnDto20 = new Button();
            btnPrecio = new Button();
            btnCantidad = new Button();
            btnSocio = new Button();
            btnCalcular = new Button();
            lblResumen = new Label();
            flowLayoutPanel1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.SteelBlue;
            flowLayoutPanel1.Controls.Add(textBox1);
            flowLayoutPanel1.Controls.Add(tableLayoutPanel1);
            flowLayoutPanel1.Controls.Add(lblResumen);
            flowLayoutPanel1.Location = new Point(268, 89);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(336, 390);
            flowLayoutPanel1.TabIndex = 1;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox1.BackColor = SystemColors.ScrollBar;
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Location = new Point(3, 9);
            textBox1.Margin = new Padding(3, 9, 3, 3);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(327, 23);
            textBox1.TabIndex = 2;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            tableLayoutPanel1.Controls.Add(button20, 0, 4);
            tableLayoutPanel1.Controls.Add(button17, 0, 0);
            tableLayoutPanel1.Controls.Add(button18, 1, 0);
            tableLayoutPanel1.Controls.Add(button19, 2, 0);
            tableLayoutPanel1.Controls.Add(button8, 3, 2);
            tableLayoutPanel1.Controls.Add(button12, 3, 3);
            tableLayoutPanel1.Controls.Add(button10, 1, 4);
            tableLayoutPanel1.Controls.Add(button5, 0, 3);
            tableLayoutPanel1.Controls.Add(button6, 1, 3);
            tableLayoutPanel1.Controls.Add(button7, 2, 3);
            tableLayoutPanel1.Controls.Add(button13, 0, 2);
            tableLayoutPanel1.Controls.Add(button14, 1, 2);
            tableLayoutPanel1.Controls.Add(button15, 2, 2);
            tableLayoutPanel1.Controls.Add(button1, 0, 1);
            tableLayoutPanel1.Controls.Add(button2, 1, 1);
            tableLayoutPanel1.Controls.Add(button3, 2, 1);
            tableLayoutPanel1.Controls.Add(button9, 2, 4);
            tableLayoutPanel1.Controls.Add(button11, 3, 4);
            tableLayoutPanel1.Controls.Add(button4, 3, 1);
            tableLayoutPanel1.Controls.Add(button16, 3, 0);
            tableLayoutPanel1.Controls.Add(btnIva0, 0, 5);
            tableLayoutPanel1.Controls.Add(btnIva4, 1, 5);
            tableLayoutPanel1.Controls.Add(btnIva10, 2, 5);
            tableLayoutPanel1.Controls.Add(btnIva21, 3, 5);
            tableLayoutPanel1.Controls.Add(btnDto0, 0, 6);
            tableLayoutPanel1.Controls.Add(btnDto5, 1, 6);
            tableLayoutPanel1.Controls.Add(btnDto10, 2, 6);
            tableLayoutPanel1.Controls.Add(btnDto20, 3, 6);
            tableLayoutPanel1.Controls.Add(btnPrecio, 0, 7);
            tableLayoutPanel1.Controls.Add(btnCantidad, 1, 7);
            tableLayoutPanel1.Controls.Add(btnSocio, 2, 7);
            tableLayoutPanel1.Controls.Add(btnCalcular, 3, 7);
            tableLayoutPanel1.Location = new Point(3, 52);
            tableLayoutPanel1.Margin = new Padding(3, 40, 3, 3);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 8;
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.Size = new Size(327, 237);
            tableLayoutPanel1.TabIndex = 2;
            // 
            // button20
            // 
            button20.BackColor = SystemColors.ActiveCaption;
            button20.Location = new Point(3, 119);
            button20.Name = "button20";
            button20.Size = new Size(75, 23);
            button20.TabIndex = 12;
            button20.Text = "+/-";
            button20.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            button17.BackColor = SystemColors.Highlight;
            button17.Location = new Point(3, 3);
            button17.Name = "button17";
            button17.Size = new Size(75, 23);
            button17.TabIndex = 2;
            button17.Text = "[ X ]";
            button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            button18.BackColor = SystemColors.Highlight;
            button18.Location = new Point(84, 3);
            button18.Name = "button18";
            button18.Size = new Size(75, 23);
            button18.TabIndex = 3;
            button18.Text = "C";
            button18.UseVisualStyleBackColor = false;
            button18.Click += limpiarClick;
            // 
            // button19
            // 
            button19.BackColor = SystemColors.Highlight;
            button19.Location = new Point(165, 3);
            button19.Name = "button19";
            button19.Size = new Size(75, 23);
            button19.TabIndex = 4;
            button19.Text = "º/o";
            button19.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.Highlight;
            button8.Location = new Point(246, 61);
            button8.Name = "button8";
            button8.Size = new Size(75, 23);
            button8.TabIndex = 7;
            button8.Text = "-";
            button8.UseVisualStyleBackColor = false;
            button8.Click += operadorClick;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.Highlight;
            button12.Location = new Point(246, 90);
            button12.Name = "button12";
            button12.Size = new Size(75, 23);
            button12.TabIndex = 11;
            button12.Text = "+";
            button12.UseVisualStyleBackColor = false;
            button12.Click += operadorClick;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.ActiveCaption;
            button10.Location = new Point(84, 119);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 9;
            button10.Text = "0";
            button10.UseVisualStyleBackColor = false;
            button10.Click += numeroClick;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ActiveCaption;
            button5.Location = new Point(3, 90);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 4;
            button5.Text = "1";
            button5.UseVisualStyleBackColor = false;
            button5.Click += numeroClick;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.ActiveCaption;
            button6.Location = new Point(84, 90);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 5;
            button6.Text = "2";
            button6.UseVisualStyleBackColor = false;
            button6.Click += numeroClick;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.ActiveCaption;
            button7.Location = new Point(165, 90);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 6;
            button7.Text = "3";
            button7.UseVisualStyleBackColor = false;
            button7.Click += numeroClick;
            // 
            // button13
            // 
            button13.BackColor = SystemColors.ActiveCaption;
            button13.Location = new Point(3, 61);
            button13.Name = "button13";
            button13.Size = new Size(75, 23);
            button13.TabIndex = 3;
            button13.Text = "4";
            button13.UseVisualStyleBackColor = false;
            button13.Click += numeroClick;
            // 
            // button14
            // 
            button14.BackColor = SystemColors.ActiveCaption;
            button14.Location = new Point(84, 61);
            button14.Name = "button14";
            button14.Size = new Size(75, 23);
            button14.TabIndex = 4;
            button14.Text = "5";
            button14.UseVisualStyleBackColor = false;
            button14.Click += numeroClick;
            // 
            // button15
            // 
            button15.BackColor = SystemColors.ActiveCaption;
            button15.Location = new Point(165, 61);
            button15.Name = "button15";
            button15.Size = new Size(75, 23);
            button15.TabIndex = 5;
            button15.Text = "6";
            button15.UseVisualStyleBackColor = false;
            button15.Click += numeroClick;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaption;
            button1.Location = new Point(3, 32);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "7";
            button1.UseVisualStyleBackColor = false;
            button1.Click += numeroClick;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaption;
            button2.Location = new Point(84, 32);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 2;
            button2.Text = "8";
            button2.UseVisualStyleBackColor = false;
            button2.Click += numeroClick;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveCaption;
            button3.Location = new Point(165, 32);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 2;
            button3.Text = "9";
            button3.UseVisualStyleBackColor = false;
            button3.Click += numeroClick;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.ActiveCaption;
            button9.Location = new Point(165, 119);
            button9.Name = "button9";
            button9.Size = new Size(75, 23);
            button9.TabIndex = 8;
            button9.Text = ",";
            button9.UseVisualStyleBackColor = false;
            button9.Click += numeroClick;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.Highlight;
            button11.Location = new Point(246, 119);
            button11.Name = "button11";
            button11.Size = new Size(75, 23);
            button11.TabIndex = 10;
            button11.Text = "=";
            button11.UseVisualStyleBackColor = false;
            button11.Click += igualClick;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.Highlight;
            button4.Location = new Point(246, 32);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 3;
            button4.Text = "*";
            button4.UseVisualStyleBackColor = false;
            button4.Click += operadorClick;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.Highlight;
            button16.Location = new Point(246, 3);
            button16.Name = "button16";
            button16.Size = new Size(75, 23);
            button16.TabIndex = 6;
            button16.Text = "/";
            button16.UseVisualStyleBackColor = false;
            button16.Click += operadorClick;
            // 
            // btnIva0
            // 
            btnIva0.BackColor = SystemColors.Highlight;
            btnIva0.Location = new Point(3, 148);
            btnIva0.Name = "btnIva0";
            btnIva0.Size = new Size(75, 23);
            btnIva0.TabIndex = 13;
            btnIva0.Text = "IVA 0%";
            btnIva0.UseVisualStyleBackColor = false;
            btnIva0.Click += ivaClick;
            // 
            // btnIva4
            // 
            btnIva4.BackColor = SystemColors.Highlight;
            btnIva4.Location = new Point(84, 148);
            btnIva4.Name = "btnIva4";
            btnIva4.Size = new Size(75, 23);
            btnIva4.TabIndex = 14;
            btnIva4.Text = "IVA 4%";
            btnIva4.UseVisualStyleBackColor = false;
            btnIva4.Click += ivaClick;
            // 
            // btnIva10
            // 
            btnIva10.BackColor = SystemColors.Highlight;
            btnIva10.Location = new Point(165, 148);
            btnIva10.Name = "btnIva10";
            btnIva10.Size = new Size(75, 23);
            btnIva10.TabIndex = 15;
            btnIva10.Text = "IVA 10%";
            btnIva10.UseVisualStyleBackColor = false;
            btnIva10.Click += ivaClick;
            // 
            // btnIva21
            // 
            btnIva21.BackColor = SystemColors.Highlight;
            btnIva21.Location = new Point(246, 148);
            btnIva21.Name = "btnIva21";
            btnIva21.Size = new Size(75, 23);
            btnIva21.TabIndex = 16;
            btnIva21.Text = "IVA 21%";
            btnIva21.UseVisualStyleBackColor = false;
            btnIva21.Click += ivaClick;
            // 
            // btnDto0
            // 
            btnDto0.BackColor = SystemColors.Highlight;
            btnDto0.Location = new Point(3, 177);
            btnDto0.Name = "btnDto0";
            btnDto0.Size = new Size(75, 23);
            btnDto0.TabIndex = 17;
            btnDto0.Text = "Dto 0%";
            btnDto0.UseVisualStyleBackColor = false;
            btnDto0.Click += descuentoClick;
            // 
            // btnDto5
            // 
            btnDto5.BackColor = SystemColors.Highlight;
            btnDto5.Location = new Point(84, 177);
            btnDto5.Name = "btnDto5";
            btnDto5.Size = new Size(75, 23);
            btnDto5.TabIndex = 18;
            btnDto5.Text = "Dto 5%";
            btnDto5.UseVisualStyleBackColor = false;
            btnDto5.Click += descuentoClick;
            // 
            // btnDto10
            // 
            btnDto10.BackColor = SystemColors.Highlight;
            btnDto10.Location = new Point(165, 177);
            btnDto10.Name = "btnDto10";
            btnDto10.Size = new Size(75, 23);
            btnDto10.TabIndex = 19;
            btnDto10.Text = "Dto 10%";
            btnDto10.UseVisualStyleBackColor = false;
            btnDto10.Click += descuentoClick;
            // 
            // btnDto20
            // 
            btnDto20.BackColor = SystemColors.Highlight;
            btnDto20.Location = new Point(246, 177);
            btnDto20.Name = "btnDto20";
            btnDto20.Size = new Size(75, 23);
            btnDto20.TabIndex = 20;
            btnDto20.Text = "Dto 20%";
            btnDto20.UseVisualStyleBackColor = false;
            btnDto20.Click += descuentoClick;
            // 
            // btnPrecio
            // 
            btnPrecio.BackColor = SystemColors.Highlight;
            btnPrecio.Location = new Point(3, 206);
            btnPrecio.Name = "btnPrecio";
            btnPrecio.Size = new Size(75, 23);
            btnPrecio.TabIndex = 21;
            btnPrecio.Text = "Precio";
            btnPrecio.UseVisualStyleBackColor = false;
            btnPrecio.Click += precioClick;
            // 
            // btnCantidad
            // 
            btnCantidad.BackColor = SystemColors.Highlight;
            btnCantidad.Location = new Point(84, 206);
            btnCantidad.Name = "btnCantidad";
            btnCantidad.Size = new Size(75, 23);
            btnCantidad.TabIndex = 22;
            btnCantidad.Text = "Cantidad";
            btnCantidad.UseVisualStyleBackColor = false;
            btnCantidad.Click += cantidadClick;
            // 
            // btnSocio
            // 
            btnSocio.BackColor = SystemColors.Highlight;
            btnSocio.Location = new Point(165, 206);
            btnSocio.Name = "btnSocio";
            btnSocio.Size = new Size(75, 23);
            btnSocio.TabIndex = 23;
            btnSocio.Text = "Socio 30%";
            btnSocio.UseVisualStyleBackColor = false;
            btnSocio.Click += socioClick;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = SystemColors.Highlight;
            btnCalcular.Location = new Point(246, 206);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 24;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += calcularClick;
            // 
            // lblResumen
            // 
            lblResumen.ForeColor = Color.White;
            lblResumen.Location = new Point(3, 297);
            lblResumen.Margin = new Padding(3, 5, 3, 0);
            lblResumen.Name = "lblResumen";
            lblResumen.Size = new Size(327, 80);
            lblResumen.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(938, 717);
            Controls.Add(flowLayoutPanel1);
            Name = "Form1";
            Text = "IVA Calculator";
            Load += Form1_Load;
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private FlowLayoutPanel flowLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel1;
        private Button button2;
        private Button button1;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private TextBox textBox1;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button btnIva0;
        private Button btnIva4;
        private Button btnIva10;
        private Button btnIva21;
        private Button btnDto0;
        private Button btnDto5;
        private Button btnDto10;
        private Button btnDto20;
        private Button btnPrecio;
        private Button btnCantidad;
        private Button btnSocio;
        private Button btnCalcular;
        private Label lblResumen;
    }
}
